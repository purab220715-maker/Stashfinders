# StashFinder 0.2.0 — Minecraft Java 1.21.11

A client-side Fabric mod that outlines selected block types in chunks already loaded by the local Minecraft client.

## Features

- Press **Right Shift** to open the menu.
- Search the category list.
- Master highlighting ON/OFF.
- Independent category ON/OFF buttons.
- Settings saved in `config/stashfinder.json`.
- Categories: chests, trapped chests, every shulker-box colour, Ender Chests, barrels, gold blocks, diamond blocks, emerald blocks, netherite blocks, beacons, and ancient debris.
- The scanner incrementally checks columns in a 32-block radius around the player's current chunk and draws coloured block outlines for matches within 96 blocks.

## Important limits

This is client-side only. It can inspect only block data the server has already sent to the client in loaded chunks. It does not read server files, request hidden chunks, or discover blocks in chunks the client has not received. The render pass uses Minecraft’s line render layer. Through-wall behavior and Lunar compatibility have not been verified in-game.

## Build online with GitHub Actions

1. Create a GitHub repository and upload the contents of this folder (not the ZIP as a single file).
2. Open the repository's **Actions** tab.
3. Choose **Build StashFinder** and click **Run workflow** (or push to `main`).
4. When the run succeeds, open it and download the `StashFinder-1.21.11` artifact.
5. The artifact contains the compiled `.jar` from `build/libs`.

Toolchain: Java 21, Minecraft 1.21.11, Fabric Loader 0.19.3, Fabric API 0.141.4+1.21.11, Fabric Loom Remap 1.17.13.

## Lunar Client

Lunar's bundled Fabric support does not guarantee compatibility with every third-party mod. Test in a local world first, and only use it on a multiplayer server if the server rules allow client-side highlighting mods.
