package com.example.stashfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Scans only block states in chunks that are already loaded on this client. */
public final class StashFinderScanner {
    private static final int RADIUS = 32;
    private static final int WIDTH = RADIUS * 2 + 1;
    private static final int COLUMNS_PER_TICK = 6;
    private static final int RESCAN_TICKS = 1200;

    private static final Map<Long, List<FoundBlock>> FOUND_BY_COLUMN = new HashMap<>();
    private static int centerChunkX = Integer.MIN_VALUE;
    private static int centerChunkZ = Integer.MIN_VALUE;
    private static int cursor;
    private static int ticks;

    private StashFinderScanner() { }

    public static void tick(Minecraft client) {
        if (client.level == null || client.player == null) {
            reset();
            return;
        }

        int playerChunkX = client.player.blockPosition().getX() >> 4;
        int playerChunkZ = client.player.blockPosition().getZ() >> 4;
        if (playerChunkX != centerChunkX || playerChunkZ != centerChunkZ) {
            centerChunkX = playerChunkX;
            centerChunkZ = playerChunkZ;
            cursor = 0;
            FOUND_BY_COLUMN.clear();
        }

        if (++ticks >= RESCAN_TICKS) {
            ticks = 0;
            cursor = 0;
        }

        int centerX = (centerChunkX << 4) + 8;
        int centerZ = (centerChunkZ << 4) + 8;
        int minX = centerX - RADIUS;
        int minZ = centerZ - RADIUS;
        int totalColumns = WIDTH * WIDTH;

        for (int i = 0; i < COLUMNS_PER_TICK; i++) {
            int index = cursor++ % totalColumns;
            int x = minX + (index % WIDTH);
            int z = minZ + (index / WIDTH);
            scanColumn(client.level, x, z);
        }
    }

    private static void scanColumn(Level level, int x, int z) {
        long key = columnKey(x, z);
        List<FoundBlock> matches = new ArrayList<>();
        int minY = level.getMinY();
        int maxY = level.getMaxY();
        BlockPos.Mutable cursorPos = new BlockPos.Mutable(x, minY, z);

        // hasChunkAt is false for chunks the client has not received; those are skipped.
        if (level.hasChunkAt(cursorPos)) {
            for (int y = minY; y < maxY; y++) {
                cursorPos.set(x, y, z);
                String category = categoryFor(level.getBlockState(cursorPos));
                if (category != null) {
                    matches.add(new FoundBlock(cursorPos.immutable(), category));
                }
            }
        }
        FOUND_BY_COLUMN.put(key, matches);
    }

    private static String categoryFor(BlockState state) {
        if (state.is(Blocks.CHEST)) return "Chests";
        if (state.is(Blocks.TRAPPED_CHEST)) return "Trapped Chests";
        if (state.getBlock() instanceof ShulkerBoxBlock) return "Shulker Boxes";
        if (state.is(Blocks.ENDER_CHEST)) return "Ender Chests";
        if (state.is(Blocks.BARREL)) return "Barrels";
        if (state.is(Blocks.GOLD_BLOCK)) return "Gold Blocks";
        if (state.is(Blocks.DIAMOND_BLOCK)) return "Diamond Blocks";
        if (state.is(Blocks.EMERALD_BLOCK)) return "Emerald Blocks";
        if (state.is(Blocks.NETHERITE_BLOCK)) return "Netherite Blocks";
        if (state.is(Blocks.BEACON)) return "Beacons";
        if (state.is(Blocks.ANCIENT_DEBRIS)) return "Ancient Debris";
        return null;
    }

    public static Iterable<FoundBlock> foundBlocks() {
        List<FoundBlock> all = new ArrayList<>();
        for (List<FoundBlock> column : FOUND_BY_COLUMN.values()) all.addAll(column);
        return all;
    }

    private static long columnKey(int x, int z) {
        return ((long) x << 32) ^ (z & 0xffffffffL);
    }

    private static void reset() {
        FOUND_BY_COLUMN.clear();
        centerChunkX = Integer.MIN_VALUE;
        centerChunkZ = Integer.MIN_VALUE;
        cursor = 0;
        ticks = 0;
    }

    public record FoundBlock(BlockPos pos, String category) { }
}
