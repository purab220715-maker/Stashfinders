package com.example.stashfinder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class StashFinderConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("stashfinder.json");
    private static final Map<String, Boolean> ENABLED = new LinkedHashMap<>();
    private static boolean masterEnabled = true;

    static {
        ENABLED.put("Chests", true);
        ENABLED.put("Trapped Chests", true);
        ENABLED.put("Shulker Boxes", true);
        ENABLED.put("Ender Chests", true);
        ENABLED.put("Barrels", true);
        ENABLED.put("Gold Blocks", true);
        ENABLED.put("Diamond Blocks", true);
        ENABLED.put("Emerald Blocks", true);
        ENABLED.put("Netherite Blocks", true);
        ENABLED.put("Beacons", false);
        ENABLED.put("Ancient Debris", false);
        load();
    }

    public static boolean isMasterEnabled() { return masterEnabled; }
    public static void setMasterEnabled(boolean value) { masterEnabled = value; save(); }
    public static boolean isEnabled(String name) { return ENABLED.getOrDefault(name, false); }
    public static void setEnabled(String name, boolean value) { ENABLED.put(name, value); save(); }
    public static Map<String, Boolean> entries() { return new LinkedHashMap<>(ENABLED); }

    public static float[] color(String category) {
        return switch (category) {
            case "Chests" -> rgb(255, 190, 45);
            case "Trapped Chests" -> rgb(255, 90, 65);
            case "Shulker Boxes" -> rgb(190, 105, 255);
            case "Ender Chests" -> rgb(65, 235, 185);
            case "Barrels" -> rgb(190, 145, 85);
            case "Gold Blocks" -> rgb(255, 220, 40);
            case "Diamond Blocks" -> rgb(65, 225, 245);
            case "Emerald Blocks" -> rgb(55, 235, 115);
            case "Netherite Blocks" -> rgb(190, 190, 205);
            case "Beacons" -> rgb(100, 255, 245);
            case "Ancient Debris" -> rgb(225, 115, 70);
            default -> rgb(255, 255, 255);
        };
    }

    private static float[] rgb(int r, int g, int b) {
        return new float[]{r / 255.0f, g / 255.0f, b / 255.0f};
    }

    private static void load() {
        if (!Files.exists(FILE)) return;
        try {
            ConfigData data = GSON.fromJson(Files.readString(FILE), ConfigData.class);
            if (data != null) {
                masterEnabled = data.masterEnabled;
                if (data.blocks != null) ENABLED.putAll(data.blocks);
            }
        } catch (Exception ignored) { }
    }

    private static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(new ConfigData(masterEnabled, ENABLED)));
        } catch (IOException ignored) { }
    }

    private static final class ConfigData {
        boolean masterEnabled;
        Map<String, Boolean> blocks;
        ConfigData(boolean masterEnabled, Map<String, Boolean> blocks) {
            this.masterEnabled = masterEnabled;
            this.blocks = new LinkedHashMap<>(blocks);
        }
    }
}
