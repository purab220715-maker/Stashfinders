package com.example.stashfinder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class StashFinderScreen extends Screen {
    private final Screen parent;
    private EditBox search;
    private final Map<String, Button> buttonsByName = new LinkedHashMap<>();
    private Button masterButton;

    public StashFinderScreen(Screen parent) {
        super(Component.literal("StashFinder"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int panelWidth = Math.min(430, this.width - 24);
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(12, (this.height - 310) / 2);

        search = new EditBox(this.font, left + 16, top + 48, panelWidth - 32, 20,
                Component.literal("Search blocks"));
        search.setHint(Component.literal("Search blocks..."));
        search.setResponder(this::applySearch);
        addRenderableWidget(search);

        masterButton = Button.builder(masterText(), button -> {
            StashFinderConfig.setMasterEnabled(!StashFinderConfig.isMasterEnabled());
            refreshButtons();
        }).bounds(left + 16, top + 76, panelWidth - 32, 22).build();
        addRenderableWidget(masterButton);

        List<String> names = new ArrayList<>(StashFinderConfig.entries().keySet());
        int gap = 8;
        int buttonWidth = (panelWidth - 40 - gap) / 2;
        int row = 0;
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            int column = i % 2;
            if (column == 0 && i > 0) row++;
            int x = left + 16 + column * (buttonWidth + gap);
            int y = top + 106 + row * 25;
            Button button = Button.builder(blockText(name), b -> {
                StashFinderConfig.setEnabled(name, !StashFinderConfig.isEnabled(name));
                refreshButtons();
            }).bounds(x, y, buttonWidth, 21).build();
            buttonsByName.put(name, button);
            addRenderableWidget(button);
        }

        addRenderableWidget(Button.builder(Component.literal("Close"), button -> onClose())
                .bounds(left + 16, Math.min(this.height - 32, top + 270), panelWidth - 32, 20).build());
        setInitialFocus(search);
        applySearch("");
        refreshButtons();
    }

    private Component masterText() {
        return Component.literal("MASTER HIGHLIGHTING: " + (StashFinderConfig.isMasterEnabled() ? "ON" : "OFF"));
    }

    private Component blockText(String name) {
        return Component.literal(name + "  •  " + (StashFinderConfig.isEnabled(name) ? "ON" : "OFF"));
    }

    private void applySearch(String value) {
        String needle = value == null ? "" : value.toLowerCase(Locale.ROOT).trim();
        for (Map.Entry<String, Button> entry : buttonsByName.entrySet()) {
            entry.getValue().visible = entry.getKey().toLowerCase(Locale.ROOT).contains(needle);
        }
    }

    private void refreshButtons() {
        if (masterButton != null) masterButton.setMessage(masterText());
        for (Map.Entry<String, Button> entry : buttonsByName.entrySet()) {
            entry.getValue().setMessage(blockText(entry.getKey()));
            entry.getValue().active = StashFinderConfig.isMasterEnabled();
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        int panelWidth = Math.min(430, this.width - 24);
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(12, (this.height - 310) / 2);
        graphics.fill(left, top, left + panelWidth, Math.min(this.height - 8, top + 310), 0xE91A1D27);
        graphics.fill(left, top, left + panelWidth, top + 3, 0xFF9B65FF);
        graphics.drawCenteredString(this.font, "STASHFINDER", this.width / 2, top + 12, 0xFFFFFFFF);
        graphics.drawCenteredString(this.font, "CLIENT-SIDE BLOCK HIGHLIGHTER", this.width / 2, top + 29, 0xFFB8B8C8);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
