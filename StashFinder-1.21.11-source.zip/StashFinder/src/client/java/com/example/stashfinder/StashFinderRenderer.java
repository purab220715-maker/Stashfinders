package com.example.stashfinder;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.world.phys.Vec3;

public final class StashFinderRenderer {
    private static final double MAX_RENDER_DISTANCE_SQR = 96.0 * 96.0;

    private StashFinderRenderer() { }

    public static void render(WorldRenderContext context) {
        Minecraft client = Minecraft.getInstance();
        if (!StashFinderConfig.isMasterEnabled() || client.level == null || client.player == null) return;

        MultiBufferSource consumers = context.consumers();
        if (consumers == null) return;

        Vec3 camera = client.gameRenderer.getMainCamera().getPosition();
        PoseStack matrices = context.matrices();
        VertexConsumer lines = consumers.getBuffer(RenderTypes.LINES);

        matrices.pushPose();
        matrices.translate(-camera.x, -camera.y, -camera.z);
        PoseStack.Pose pose = matrices.last();

        for (StashFinderScanner.FoundBlock found : StashFinderScanner.foundBlocks()) {
            if (!StashFinderConfig.isEnabled(found.category())) continue;
            double cx = found.pos().getX() + 0.5 - camera.x;
            double cy = found.pos().getY() + 0.5 - camera.y;
            double cz = found.pos().getZ() + 0.5 - camera.z;
            if (cx * cx + cy * cy + cz * cz > MAX_RENDER_DISTANCE_SQR) continue;

            float[] color = StashFinderConfig.color(found.category());
            float x0 = (float) (found.pos().getX() + 0.025);
            float y0 = (float) (found.pos().getY() + 0.025);
            float z0 = (float) (found.pos().getZ() + 0.025);
            float x1 = x0 + 0.95f;
            float y1 = y0 + 0.95f;
            float z1 = z0 + 0.95f;
            drawBox(lines, pose, x0, y0, z0, x1, y1, z1, color);
        }
        matrices.popPose();
    }

    private static void drawBox(VertexConsumer out, PoseStack.Pose pose,
                                float x0, float y0, float z0,
                                float x1, float y1, float z1, float[] color) {
        // Bottom rectangle
        line(out, pose, x0,y0,z0, x1,y0,z0, color);
        line(out, pose, x1,y0,z0, x1,y0,z1, color);
        line(out, pose, x1,y0,z1, x0,y0,z1, color);
        line(out, pose, x0,y0,z1, x0,y0,z0, color);
        // Top rectangle
        line(out, pose, x0,y1,z0, x1,y1,z0, color);
        line(out, pose, x1,y1,z0, x1,y1,z1, color);
        line(out, pose, x1,y1,z1, x0,y1,z1, color);
        line(out, pose, x0,y1,z1, x0,y1,z0, color);
        // Vertical edges
        line(out, pose, x0,y0,z0, x0,y1,z0, color);
        line(out, pose, x1,y0,z0, x1,y1,z0, color);
        line(out, pose, x1,y0,z1, x1,y1,z1, color);
        line(out, pose, x0,y0,z1, x0,y1,z1, color);
    }

    private static void line(VertexConsumer out, PoseStack.Pose pose,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float[] color) {
        out.addVertex(pose, ax, ay, az).setColor(color[0], color[1], color[2], 1.0f)
                .setNormal(pose, 0.0f, 1.0f, 0.0f);
        out.addVertex(pose, bx, by, bz).setColor(color[0], color[1], color[2], 1.0f)
                .setNormal(pose, 0.0f, 1.0f, 0.0f);
    }
}
